# استيراد المكتبات والوحدات الضرورية
import config
from bot.bot import main  # قم بتعديل هذا الاستيراد بناءً على هيكل مشروعك

if __name__ == '__main__':
    main()
