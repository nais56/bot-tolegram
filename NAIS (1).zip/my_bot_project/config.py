
# config.py

# تكوين توكن البوت
bot_token = '6872933899:AAHRfBBmTE0ii-vEHxujZXrwOvwybNLzIsk'

# تكوين مفتاح التطبيق (app key) من AliExpress
app_key = '502370'

# تكوين قاعدة البيانات SQLite
database_name = 'product_data.db'

# تكوين لدعم تخفيض السلة
cart_discount_enabled = True

# تكوينات للإشعارات
fcm_api_key = 'YOUR_FCM_API_KEY'
fcm_project_id = 'YOUR_FCM_PROJECT_ID'
